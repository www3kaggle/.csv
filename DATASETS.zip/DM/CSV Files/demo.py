# -*- coding: utf-8 -*-


import numpy as np
import pandas as pd

#load dataset
dataset = pd.read_csv('data.csv')