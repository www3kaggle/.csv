# -*- coding: utf-8 -*-
# *** Spyder Python Console History Log ***

## ---(Wed Aug  2 19:37:15 2023)---
import numpy as np
import pandas as pd

#load dataset
dataset = pd.read_csv('DataPreprocessing.csv')
import numpy as np
import pandas as pd

#load dataset
dataset = pd.read_csv('data.csv')
import numpy as np
import pandas as pd

#load dataset
dataset = pd.read_csv('C:\Users\siddhii\.spyder-py3')
import numpy as np
import pandas as pd

#load dataset
dataset = pd.read_csv(data.csv)
import numpy as np
import pandas as pd

#load dataset
dataset = pd.read_csv(C:\Users\siddhii\.spyder-py3)
import numpy as np
import pandas as pd

#load dataset
dataset = pd.read_csv('DataPreprocessing')
import numpy as np
import pandas as pd

#load dataset
dataset = pd.read_csv('DataPreprocessing.csv')
dataset = pd.read_csv('DataPreprocessing.csv')

## ---(Fri Aug  4 20:08:23 2023)---
from numpy as np
from pandas as pd

dataset = pd.read_csv('titanic.csv')
import numpy as np
import pandas as pd

dataset = pd.read_csv('titanic.csv')
import numpy as np
import pandas as pd

dataset = pd.read_csv('/Users/siddhii/Downloads/DataPreprocessing.csv')
import numpy as np
import pandas as pd

dataset = pd.read_csv('/Users/siddhii/Downloads/DataPreprocessing.csv')

## ---(Wed Nov  1 13:09:32 2023)---
pip install
pip install graphviz
runfile('C:/Users/siddhii/.spyder-py3/lab.py', wdir='C:/Users/siddhii/.spyder-py3')

## ---(Wed Nov  1 13:41:20 2023)---
pip install graphviz
pip install graphviz pydotplus
runfile('C:/Users/siddhii/.spyder-py3/lab.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/slip1_2.py', wdir='C:/Users/siddhii/.spyder-py3')

## ---(Mon Nov 13 18:14:32 2023)---
runfile('C:/Users/siddhii/.spyder-py3/untitled2.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled3.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled4.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled5.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled6.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled7.py', wdir='C:/Users/siddhii/.spyder-py3')
clear
runfile('C:/Users/siddhii/.spyder-py3/untitled7.py', wdir='C:/Users/siddhii/.spyder-py3')

## ---(Tue Nov 14 12:30:28 2023)---
runfile('C:/Users/siddhii/.spyder-py3/untitled2.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled3.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled4.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled3.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled5.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled6.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled7.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled9.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled10.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled12.py', wdir='C:/Users/siddhii/.spyder-py3')
pip install apyori
runfile('C:/Users/siddhii/.spyder-py3/untitled12.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled13.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled14.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled15.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled14.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled16.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled17.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled18.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled19.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled20.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled19.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled21.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled22.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled23.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled24.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled25.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled26.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled27.py', wdir='C:/Users/siddhii/.spyder-py3')
pip install mlxtend
runfile('C:/Users/siddhii/.spyder-py3/untitled27.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled28.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled29.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled30.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled31.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled32.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled33.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled34.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled35.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled33.py', wdir='C:/Users/siddhii/.spyder-py3')

## ---(Thu Nov 23 23:02:16 2023)---
runfile('C:/Users/siddhii/.spyder-py3/untitled2.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled3.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled4.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled6.py', wdir='C:/Users/siddhii/.spyder-py3')

## ---(Sun Nov 26 22:06:13 2023)---
runfile('C:/Users/siddhii/.spyder-py3/untitled2.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled3.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled4.py', wdir='C:/Users/siddhii/.spyder-py3')
runfile('C:/Users/siddhii/.spyder-py3/untitled5.py', wdir='C:/Users/siddhii/.spyder-py3')