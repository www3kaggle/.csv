# -*- coding: utf-8 -*-
"""
Created on Fri Aug  4 20:08:48 2023

@author: siddhii
"""

import numpy as np
import pandas as pd

dataset = pd.read_csv('/Users/siddhii/Downloads/DataPreprocessing.csv')